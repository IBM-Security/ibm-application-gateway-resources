/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022, 2025
 */

var params = {}, postBody = location.hash.substring(1);

const urlSearchParams = new URLSearchParams(postBody);

for (const [key,value] of urlSearchParams.entries()){
    params[decodeURIComponent(key)] = decodeURIComponent(value);
}

var req_url = 'https://' + window.location.host + '/pkmsoidc';
var xmlhttp = new XMLHttpRequest();

xmlhttp.onreadystatechange = function(){
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
        document.write(xmlhttp.responseText);
        document.close();
    }
}

xmlhttp.open('POST', req_url, true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
xmlhttp.send(postBody);