/*
 * IBM Confidential
 * PID 5725-V89 5725-V90 5737-F02
 *
 * Copyright IBM Corp. 2022
 */

var params = {}, postBody = location.hash.substring(1),
            regex = /([^&=]+)=([^&]*)/g, m;

while (m = regex.exec(postBody)) {
    params[decodeURIComponent(m[1])] = decodeURIComponent(m[2]);
}

var req_url = 'https://' + window.location.host + '/pkmsoidc';
var xmlhttp = new XMLHttpRequest();

xmlhttp.onreadystatechange = function(){
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
        document.write(xmlhttp.responseText);
        document.close();
    }
}

xmlhttp.open('POST', req_url, true);
xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
xmlhttp.send(postBody);